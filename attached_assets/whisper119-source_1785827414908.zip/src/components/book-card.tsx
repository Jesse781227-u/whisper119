import { Link } from "@tanstack/react-router";
import { Check, Plus } from "lucide-react";
import { toast } from "sonner";
import { formatPrice, type Book } from "@/data/books";
import { useCart } from "@/lib/cart";
import { cn } from "@/lib/utils";

export function BookCover({
  book,
  className,
  priority,
}: {
  book: Book;
  className?: string;
  priority?: boolean;
}) {
  return (
    <div className={cn("overflow-hidden rounded-sm bg-muted book-shadow", className)}>
      <img
        src={book.cover}
        alt={`Cover of ${book.title} by ${book.author}`}
        width={672}
        height={992}
        loading={priority ? "eager" : "lazy"}
        className="h-full w-full object-cover"
      />
    </div>
  );
}

export function BookCard({ book }: { book: Book }) {
  const { add, has } = useCart();
  const inCart = has(book.id);

  return (
    <article className="group flex flex-col">
      <Link to="/book/$bookId" params={{ bookId: book.id }} className="block hover-lift">
        <BookCover book={book} className="aspect-[2/3]" />
      </Link>
      <div className="mt-4 flex flex-1 flex-col">
        <Link to="/book/$bookId" params={{ bookId: book.id }}>
          <h3 className="font-display text-base leading-snug font-semibold transition-colors group-hover:text-primary">
            {book.title}
          </h3>
        </Link>
        <p className="mt-1 text-sm text-muted-foreground">{book.author}</p>
        <div className="mt-3 flex items-center justify-between gap-2">
          <span className="text-sm font-medium">{formatPrice(book.price)}</span>
          <button
            type="button"
            onClick={() => {
              if (inCart) return;
              add(book.id);
              toast.success(`${book.title} added to your cart`);
            }}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
              inCart
                ? "border-transparent bg-accent text-accent-foreground"
                : "border-border hover:border-primary hover:bg-primary hover:text-primary-foreground",
            )}
          >
            {inCart ? <Check className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
            {inCart ? "In cart" : "Add"}
          </button>
        </div>
        <p className="mt-2 text-[11px] tracking-wide text-muted-foreground uppercase">
          {book.formats.join(" · ")}
        </p>
      </div>
    </article>
  );
}
