import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, LayoutDashboard, Receipt, ArrowLeft } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

const links = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { to: "/admin/books", label: "Books", icon: BookOpen },
  { to: "/admin/orders", label: "Orders", icon: Receipt },
];

export function StatusPill({ status }: { status: "paid" | "pending" }) {
  return (
    <span
      className={cn(
        "inline-flex rounded-full px-2.5 py-0.5 text-[11px] font-medium capitalize",
        status === "paid" ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground",
      )}
    >
      {status}
    </span>
  );
}


export function AdminShell({
  title,
  description,
  action,
  children,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  children: ReactNode;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-screen bg-background md:flex">
      <aside className="border-b border-border bg-sidebar px-4 py-4 md:w-60 md:shrink-0 md:border-r md:border-b-0 md:py-8">
        <Link to="/" className="mb-6 hidden items-center gap-2 px-2 md:flex">
          <span className="font-display text-lg font-semibold">Whisper 119</span>
        </Link>
        <nav className="flex gap-1 md:flex-col">
          {links.map((l) => {
            const active = l.to === "/admin" ? pathname === "/admin" : pathname.startsWith(l.to);
            return (
              <Link
                key={l.to}
                to={l.to}
                className={cn(
                  "flex items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors",
                  active
                    ? "bg-sidebar-accent font-medium text-sidebar-accent-foreground"
                    : "text-muted-foreground hover:bg-sidebar-accent/60",
                )}
              >
                <l.icon className="h-4 w-4" strokeWidth={1.6} />
                {l.label}
              </Link>
            );
          })}
        </nav>
        <Link
          to="/"
          className="mt-6 hidden items-center gap-2 px-3 text-xs text-muted-foreground hover:text-primary md:flex"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Back to shop
        </Link>
      </aside>

      <div className="flex-1">
        <div className="mx-auto max-w-5xl px-5 py-8 sm:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h1 className="font-display text-2xl font-semibold">{title}</h1>
              {description && (
                <p className="mt-1 text-sm text-muted-foreground">{description}</p>
              )}
            </div>
            {action}
          </div>
          <div className="mt-8">{children}</div>
        </div>
      </div>
    </div>
  );
}
