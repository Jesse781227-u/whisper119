import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About the shop — Whisper 119" },
      {
        name: "description",
        content:
          "Whisper 119 is a one-woman digital bookshop. Every title is read before it reaches the shelf, and every order is delivered instantly, worldwide.",
      },
      { property: "og:title", content: "About the shop — Whisper 119" },
      {
        property: "og:description",
        content: "A one-woman digital bookshop delivering handpicked ebooks worldwide.",
      },
    ],
  }),
  component: About,
});

function About() {
  return (
    <SiteLayout>
      <div className="mx-auto max-w-2xl px-5 py-16 sm:px-8 md:py-24">
        <p className="rule-label">About</p>
        <h1 className="mt-4 font-display text-4xl font-semibold text-balance">
          A small shop with a long reading list
        </h1>
        <div className="mt-8 space-y-5 leading-relaxed text-muted-foreground">
          <p>
            Whisper 119 is a one-person bookshop. There's no warehouse, no algorithm and no
            recommendations engine — just a shelf of titles chosen carefully and sold as clean,
            DRM-free EPUB and PDF files.
          </p>
          <p>
            Because everything here is digital, your book arrives the moment your payment clears.
            You'll get a download link on screen and a copy in your inbox, and the link keeps
            working if your laptop doesn't.
          </p>
          <p>
            Readers order from every continent. Prices are listed in USD, and checkout is handled
            by Flutterwave so you can pay with the card, bank or mobile money option that makes
            sense where you live.
          </p>
        </div>
        <dl className="mt-12 grid gap-8 border-t border-border pt-10 sm:grid-cols-3">
          <div>
            <dt className="rule-label">Delivery</dt>
            <dd className="mt-2 text-sm">Instant download + email copy</dd>
          </div>
          <div>
            <dt className="rule-label">Formats</dt>
            <dd className="mt-2 text-sm">EPUB and PDF, DRM-free</dd>
          </div>
          <div>
            <dt className="rule-label">Support</dt>
            <dd className="mt-2 text-sm">hello@whisper119.shop</dd>
          </div>
        </dl>
        <Link
          to="/shop"
          className="mt-12 inline-flex rounded-full bg-primary px-7 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
        >
          Browse the shop
        </Link>
      </div>
    </SiteLayout>
  );
}
