import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Minus } from "lucide-react";
import { useState } from "react";
import { AdminShell, StatusPill } from "@/components/admin-shell";
import { formatPrice, orders, orderTotal, type OrderStatus } from "@/data/books";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/admin/orders/")({
  head: () => ({
    meta: [
      { title: "Orders — Whisper 119 admin" },
      { name: "description", content: "All orders with payment status and download activity." },
      { property: "og:title", content: "Orders — Whisper 119 admin" },
      { property: "og:description", content: "All orders with payment and download activity." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminOrders,
});

function AdminOrders() {
  const [filter, setFilter] = useState<"all" | OrderStatus>("all");
  const rows = orders.filter((o) => filter === "all" || o.status === filter);

  return (
    <AdminShell title="Orders" description="Payment status and whether the buyer has downloaded.">
      <div className="flex gap-2">
        {(["all", "paid", "pending"] as const).map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => setFilter(f)}
            className={cn(
              "rounded-full border px-4 py-1.5 text-xs font-medium capitalize transition-colors",
              filter === f
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border text-muted-foreground hover:border-primary",
            )}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="mt-6 overflow-x-auto rounded-md border border-border bg-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left">
              <th className="rule-label px-4 py-3">Order</th>
              <th className="rule-label px-4 py-3">Buyer</th>
              <th className="rule-label px-4 py-3">Items</th>
              <th className="rule-label px-4 py-3">Amount</th>
              <th className="rule-label px-4 py-3">Status</th>
              <th className="rule-label px-4 py-3">Downloaded</th>
              <th className="rule-label px-4 py-3">Date</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((o) => (
              <tr key={o.id} className="border-b border-border last:border-0">
                <td className="px-4 py-3">
                  <Link
                    to="/admin/orders/$orderId"
                    params={{ orderId: o.id }}
                    className="font-medium hover:text-primary"
                  >
                    {o.id}
                  </Link>
                </td>
                <td className="px-4 py-3">
                  <p>{o.buyer}</p>
                  <p className="text-xs text-muted-foreground">{o.country}</p>
                </td>
                <td className="px-4 py-3 text-muted-foreground">{o.items.length}</td>
                <td className="px-4 py-3">{formatPrice(orderTotal(o))}</td>
                <td className="px-4 py-3">
                  <StatusPill status={o.status} />
                </td>
                <td className="px-4 py-3">
                  {o.downloaded ? (
                    <span className="inline-flex items-center gap-1 text-xs text-primary">
                      <Check className="h-3.5 w-3.5" /> Yes
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                      <Minus className="h-3.5 w-3.5" /> Not yet
                    </span>
                  )}
                </td>
                <td className="px-4 py-3 text-muted-foreground">{o.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 && (
          <p className="px-4 py-10 text-center text-sm text-muted-foreground">
            No {filter} orders right now.
          </p>
        )}
      </div>
    </AdminShell>
  );
}
