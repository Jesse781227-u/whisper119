import { createFileRoute, Link } from "@tanstack/react-router";
import { Download, X } from "lucide-react";
import { BookCover } from "@/components/book-card";
import { SiteLayout } from "@/components/site-layout";
import { formatPrice } from "@/data/books";
import { useCart } from "@/lib/cart";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your cart — Whisper 119" },
      {
        name: "description",
        content: "Review the ebooks in your cart before checking out. Digital delivery, no shipping.",
      },
      { property: "og:title", content: "Your cart — Whisper 119" },
      { property: "og:description", content: "Review your ebooks before checkout." },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { items, total, remove } = useCart();

  return (
    <SiteLayout>
      <div className="mx-auto max-w-5xl px-5 py-12 sm:px-8">
        <p className="rule-label">Checkout</p>
        <h1 className="mt-3 font-display text-3xl font-semibold sm:text-4xl">Your cart</h1>

        {items.length === 0 ? (
          <div className="mt-12 rounded-md border border-dashed border-border px-8 py-20 text-center">
            <h2 className="font-display text-xl font-semibold">Your cart is empty</h2>
            <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
              Nothing here yet. The shelf is just a click away.
            </p>
            <Link
              to="/shop"
              className="mt-8 inline-flex rounded-full bg-primary px-7 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Continue browsing
            </Link>
          </div>
        ) : (
          <div className="mt-10 grid gap-12 lg:grid-cols-[1fr_20rem]">
            <ul className="divide-y divide-border border-y border-border">
              {items.map((book) => (
                <li key={book.id} className="flex gap-5 py-6">
                  <Link
                    to="/book/$bookId"
                    params={{ bookId: book.id }}
                    className="w-16 shrink-0 sm:w-20"
                  >
                    <BookCover book={book} className="aspect-[2/3]" />
                  </Link>
                  <div className="flex flex-1 flex-col">
                    <Link to="/book/$bookId" params={{ bookId: book.id }}>
                      <h2 className="font-display leading-snug font-semibold hover:text-primary">
                        {book.title}
                      </h2>
                    </Link>
                    <p className="mt-1 text-sm text-muted-foreground">{book.author}</p>
                    <p className="mt-1 text-[11px] tracking-wide text-muted-foreground uppercase">
                      {book.formats.join(" · ")}
                    </p>
                    <button
                      type="button"
                      onClick={() => remove(book.id)}
                      className="mt-auto inline-flex w-fit items-center gap-1 pt-3 text-xs text-muted-foreground hover:text-destructive"
                    >
                      <X className="h-3.5 w-3.5" /> Remove
                    </button>
                  </div>
                  <span className="text-sm font-medium">{formatPrice(book.price)}</span>
                </li>
              ))}
            </ul>

            <aside className="h-fit rounded-md border border-border bg-card p-6">
              <h2 className="font-display text-lg font-semibold">Order summary</h2>
              <dl className="mt-5 space-y-3 text-sm">
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">
                    Subtotal ({items.length} {items.length === 1 ? "book" : "books"})
                  </dt>
                  <dd>{formatPrice(total)}</dd>
                </div>
                <div className="flex justify-between border-t border-border pt-3 text-base font-semibold">
                  <dt>Total</dt>
                  <dd>{formatPrice(total)}</dd>
                </div>
              </dl>
              <Link
                to="/checkout"
                className="mt-6 flex w-full items-center justify-center rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Proceed to checkout
              </Link>
              <p className="mt-4 inline-flex items-start gap-2 text-xs text-muted-foreground">
                <Download className="mt-0.5 h-3.5 w-3.5 shrink-0" strokeWidth={1.6} />
                Digital delivery — nothing ships, so there's no shipping cost.
              </p>
            </aside>
          </div>
        )}
      </div>
    </SiteLayout>
  );
}
