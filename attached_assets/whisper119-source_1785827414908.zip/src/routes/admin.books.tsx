import { createFileRoute } from "@tanstack/react-router";
import { Pencil, Plus, Trash2, Upload, X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { AdminShell } from "@/components/admin-shell";
import { books as seedBooks, categories, formatPrice } from "@/data/books";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/admin/books")({
  head: () => ({
    meta: [
      { title: "Books — Whisper 119 admin" },
      { name: "description", content: "Add, edit and remove digital titles in the catalogue." },
      { property: "og:title", content: "Books — Whisper 119 admin" },
      { property: "og:description", content: "Manage the shop's digital catalogue." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminBooks,
});

function AdminBooks() {
  const [rows, setRows] = useState(seedBooks);
  const [formOpen, setFormOpen] = useState(false);

  return (
    <AdminShell
      title="Books"
      description="Every title on the shelf. Digital only — no stock to track."
      action={
        <button
          type="button"
          onClick={() => setFormOpen(true)}
          className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
        >
          <Plus className="h-4 w-4" /> Add new book
        </button>
      }
    >
      <div className="overflow-x-auto rounded-md border border-border bg-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border text-left">
              <th className="rule-label px-4 py-3">Title</th>
              <th className="rule-label px-4 py-3">Category</th>
              <th className="rule-label px-4 py-3">Price</th>
              <th className="rule-label px-4 py-3">Format</th>
              <th className="rule-label px-4 py-3">Status</th>
              <th className="rule-label px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((b) => (
              <tr key={b.id} className="border-b border-border last:border-0">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={b.cover}
                      alt=""
                      width={672}
                      height={992}
                      loading="lazy"
                      className="h-12 w-8 rounded-xs object-cover"
                    />
                    <div>
                      <p className="font-medium">{b.title}</p>
                      <p className="text-xs text-muted-foreground">{b.author}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-muted-foreground">{b.category}</td>
                <td className="px-4 py-3">{formatPrice(b.price)}</td>
                <td className="px-4 py-3 text-muted-foreground">{b.formats.join(", ")}</td>
                <td className="px-4 py-3">
                  <span
                    className={cn(
                      "inline-flex rounded-full px-2.5 py-0.5 text-[11px] font-medium",
                      b.status === "Published"
                        ? "bg-accent text-accent-foreground"
                        : "bg-muted text-muted-foreground",
                    )}
                  >
                    {b.status}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-1">
                    <button
                      type="button"
                      aria-label={`Edit ${b.title}`}
                      onClick={() => toast("Editing is mocked in this preview")}
                      className="inline-flex h-8 w-8 items-center justify-center rounded-md hover:bg-accent"
                    >
                      <Pencil className="h-4 w-4" strokeWidth={1.6} />
                    </button>
                    <button
                      type="button"
                      aria-label={`Delete ${b.title}`}
                      onClick={() => {
                        setRows((prev) => prev.filter((x) => x.id !== b.id));
                        toast.success(`${b.title} removed`);
                      }}
                      className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-accent hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" strokeWidth={1.6} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {formOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto p-4 sm:p-8">
          <button
            type="button"
            aria-label="Close"
            onClick={() => setFormOpen(false)}
            className="absolute inset-0 bg-foreground/40"
          />
          <div className="relative w-full max-w-lg rounded-md border border-border bg-card p-6 shadow-lg">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="font-display text-lg font-semibold">Add a new book</h2>
                <p className="mt-1 text-xs text-muted-foreground">
                  Upload the cover and the reader's file. No stock quantity needed.
                </p>
              </div>
              <button type="button" onClick={() => setFormOpen(false)} aria-label="Close">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form
              className="mt-6 space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                setFormOpen(false);
                toast.success("Book saved (mock)");
              }}
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Title" placeholder="The Long, Quiet Work" />
                <Field label="Author" placeholder="Imogen Blake" />
                <Field label="Price (USD)" placeholder="12.00" type="number" />
                <div>
                  <label className="rule-label">Category</label>
                  <select className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm">
                    {categories.map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="rule-label">Description</label>
                <textarea
                  rows={3}
                  placeholder="A short editorial blurb for the shelf…"
                  className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm"
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <UploadBox label="Cover image" hint="JPG or PNG · 2:3 ratio" />
                <UploadBox label="Ebook file" hint="PDF or EPUB · up to 50MB" />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setFormOpen(false)}
                  className="rounded-full border border-border px-5 py-2.5 text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground hover:bg-primary/90"
                >
                  Save book
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminShell>
  );
}

function Field({
  label,
  placeholder,
  type = "text",
}: {
  label: string;
  placeholder: string;
  type?: string;
}) {
  return (
    <div>
      <label className="rule-label">{label}</label>
      <input
        type={type}
        placeholder={placeholder}
        className="mt-2 w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary"
      />
    </div>
  );
}

function UploadBox({ label, hint }: { label: string; hint: string }) {
  return (
    <div>
      <label className="rule-label">{label}</label>
      <div className="mt-2 flex flex-col items-center gap-1 rounded-md border border-dashed border-border px-4 py-6 text-center">
        <Upload className="h-4 w-4 text-muted-foreground" strokeWidth={1.6} />
        <span className="text-xs font-medium">Click to upload</span>
        <span className="text-[11px] text-muted-foreground">{hint}</span>
      </div>
    </div>
  );
}
