import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";

export const Route = createFileRoute("/admin/login")({
  head: () => ({
    meta: [
      { title: "Shop owner sign in — Whisper 119" },
      { name: "description", content: "Private sign in for the Whisper 119 shop owner." },
      { property: "og:title", content: "Shop owner sign in — Whisper 119" },
      { property: "og:description", content: "Private sign in for the Whisper 119 shop owner." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminLogin,
});

function AdminLogin() {
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen items-center justify-center px-5 py-16">
      <div className="w-full max-w-sm">
        <Link to="/" className="font-display text-xl font-semibold">
          Whisper 119
        </Link>
        <p className="rule-label mt-6">Shop owner</p>
        <h1 className="mt-2 font-display text-2xl font-semibold">Sign in</h1>

        <form
          className="mt-8 space-y-5"
          onSubmit={(e) => {
            e.preventDefault();
            navigate({ to: "/admin" });
          }}
        >
          <div>
            <label htmlFor="email" className="rule-label">
              Email
            </label>
            <input
              id="email"
              type="email"
              required
              defaultValue="owner@whisper119.shop"
              className="mt-2 w-full rounded-md border border-input bg-card px-4 py-3 text-sm outline-none focus:border-primary"
            />
          </div>
          <div>
            <label htmlFor="password" className="rule-label">
              Password
            </label>
            <input
              id="password"
              type="password"
              required
              defaultValue="password"
              className="mt-2 w-full rounded-md border border-input bg-card px-4 py-3 text-sm outline-none focus:border-primary"
            />
          </div>
          <button
            type="submit"
            className="w-full rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Sign in
          </button>
        </form>

        <Link
          to="/"
          className="mt-8 block text-xs text-muted-foreground underline underline-offset-4 hover:text-primary"
        >
          Back to the shop
        </Link>
      </div>
    </div>
  );
}
