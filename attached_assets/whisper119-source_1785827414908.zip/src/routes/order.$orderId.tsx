import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2, Download, Mail } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { BookCover } from "@/components/book-card";
import { SiteLayout } from "@/components/site-layout";
import { books, formatPrice, publishedBooks, type Book } from "@/data/books";
import { LAST_ORDER_KEY } from "./checkout";

type StoredOrder = {
  id: string;
  email: string;
  name: string;
  country: string;
  total: number;
  date: string;
  bookIds: string[];
};

export const Route = createFileRoute("/order/$orderId")({
  head: () => ({
    meta: [
      { title: "Order confirmed — Whisper 119" },
      {
        name: "description",
        content: "Your payment is confirmed. Download your ebooks now — a copy is also on its way by email.",
      },
      { property: "og:title", content: "Order confirmed — Whisper 119" },
      { property: "og:description", content: "Payment confirmed. Download your ebooks now." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: OrderConfirmation,
});

function OrderConfirmation() {
  const { orderId } = Route.useParams();
  const [order, setOrder] = useState<StoredOrder | null>(null);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(LAST_ORDER_KEY);
      if (raw) setOrder(JSON.parse(raw) as StoredOrder);
    } catch {
      /* ignore */
    }
  }, []);

  const purchased: Book[] = (order?.bookIds ?? [])
    .map((id) => books.find((b) => b.id === id))
    .filter((b): b is Book => Boolean(b));

  const items = purchased.length > 0 ? purchased : publishedBooks.slice(0, 1);
  const total = order?.total ?? items.reduce((s, b) => s + b.price, 0);

  return (
    <SiteLayout>
      <div className="mx-auto max-w-3xl px-5 py-16 sm:px-8">
        <div className="text-center">
          <CheckCircle2 className="mx-auto h-10 w-10 text-primary" strokeWidth={1.4} />
          <h1 className="mt-5 font-display text-3xl font-semibold sm:text-4xl">
            Thank you — your payment came through
          </h1>
          <p className="mt-3 text-sm text-muted-foreground">
            Order <span className="font-medium text-foreground">{orderId}</span>
            {order?.email ? ` · receipt sent to ${order.email}` : ""}
          </p>
        </div>

        <div className="mt-12 rounded-md border border-border bg-card">
          <div className="border-b border-border px-6 py-4">
            <p className="rule-label">Your downloads</p>
          </div>
          <ul className="divide-y divide-border">
            {items.map((book) => (
              <li key={book.id} className="flex flex-wrap items-center gap-5 px-6 py-5">
                <div className="w-14 shrink-0">
                  <BookCover book={book} className="aspect-[2/3]" />
                </div>
                <div className="min-w-40 flex-1">
                  <h2 className="font-display leading-snug font-semibold">{book.title}</h2>
                  <p className="mt-1 text-sm text-muted-foreground">{book.author}</p>
                  <p className="mt-1 text-[11px] tracking-wide text-muted-foreground uppercase">
                    {book.formats.join(" · ")}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => toast.success(`Downloading ${book.title} (${book.formats[0]})`)}
                  className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
                >
                  <Download className="h-4 w-4" strokeWidth={1.8} /> Download
                </button>
              </li>
            ))}
          </ul>
          <div className="flex justify-between border-t border-border px-6 py-4 text-sm font-semibold">
            <span>Total paid</span>
            <span>{formatPrice(total)}</span>
          </div>
        </div>

        <p className="mt-6 inline-flex items-start gap-2 text-sm text-muted-foreground">
          <Mail className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.6} />
          A copy of every file has also been emailed to you, and the links stay live — re-download
          any time.
        </p>

        <div className="mt-10">
          <Link
            to="/shop"
            className="inline-flex rounded-full border border-border px-7 py-3 text-sm font-medium transition-colors hover:border-primary hover:text-primary"
          >
            Continue shopping
          </Link>
        </div>
      </div>
    </SiteLayout>
  );
}
