import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Check, Lock, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { SiteLayout } from "@/components/site-layout";
import { countries, formatPrice } from "@/data/books";
import { useCart } from "@/lib/cart";
import { cn } from "@/lib/utils";

export const LAST_ORDER_KEY = "whisper119.lastOrder";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout — Whisper 119" },
      {
        name: "description",
        content:
          "Pay securely with Flutterwave and download your ebooks immediately. Email receipt included.",
      },
      { property: "og:title", content: "Checkout — Whisper 119" },
      { property: "og:description", content: "Pay with Flutterwave, download immediately." },
    ],
  }),
  component: Checkout,
});

function Checkout() {
  const { items, total, clear } = useCart();
  const navigate = useNavigate();
  const [step, setStep] = useState<1 | 2>(1);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [country, setCountry] = useState("Nigeria");
  const [processing, setProcessing] = useState(false);

  if (items.length === 0) {
    return (
      <SiteLayout>
        <div className="mx-auto max-w-md px-5 py-24 text-center sm:px-8">
          <h1 className="font-display text-2xl font-semibold">Nothing to check out</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Add a book to your cart and come back.
          </p>
          <Link
            to="/shop"
            className="mt-8 inline-flex rounded-full bg-primary px-7 py-3 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            Browse the shop
          </Link>
        </div>
      </SiteLayout>
    );
  }

  const pay = () => {
    setProcessing(true);
    const order = {
      id: `MRG-${Math.floor(10000 + Math.random() * 89999)}`,
      email,
      name,
      country,
      total,
      date: new Date().toISOString(),
      bookIds: items.map((b) => b.id),
    };
    window.setTimeout(() => {
      try {
        window.localStorage.setItem(LAST_ORDER_KEY, JSON.stringify(order));
      } catch {
        /* ignore */
      }
      clear();
      navigate({ to: "/order/$orderId", params: { orderId: order.id } });
    }, 1200);
  };

  return (
    <SiteLayout>
      <div className="mx-auto max-w-5xl px-5 py-12 sm:px-8">
        <p className="rule-label">Secure checkout</p>
        <h1 className="mt-3 font-display text-3xl font-semibold sm:text-4xl">Checkout</h1>

        <ol className="mt-8 flex items-center gap-4 text-sm">
          {[
            { n: 1, label: "Contact info" },
            { n: 2, label: "Payment" },
          ].map((s) => (
            <li key={s.n} className="flex items-center gap-2">
              <span
                className={cn(
                  "inline-flex h-7 w-7 items-center justify-center rounded-full border text-xs",
                  step >= s.n
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border text-muted-foreground",
                )}
              >
                {step > s.n ? <Check className="h-3.5 w-3.5" /> : s.n}
              </span>
              <span className={step >= s.n ? "font-medium" : "text-muted-foreground"}>
                {s.label}
              </span>
              {s.n === 1 && <span className="mx-2 h-px w-8 bg-border sm:w-16" />}
            </li>
          ))}
        </ol>

        <div className="mt-10 grid gap-12 lg:grid-cols-[1fr_20rem]">
          <div>
            {step === 1 ? (
              <form
                className="space-y-6"
                onSubmit={(e) => {
                  e.preventDefault();
                  setStep(2);
                }}
              >
                <div>
                  <label htmlFor="name" className="rule-label">
                    Your name
                  </label>
                  <input
                    id="name"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="mt-2 w-full rounded-md border border-input bg-card px-4 py-3 text-sm outline-none focus:border-primary"
                    placeholder="Amara Okoye"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="rule-label">
                    Email for your download link
                  </label>
                  <input
                    id="email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="mt-2 w-full rounded-md border border-input bg-card px-4 py-3 text-sm outline-none focus:border-primary"
                    placeholder="you@example.com"
                  />
                  <p className="mt-2 text-xs text-muted-foreground">
                    Your receipt and download links are sent here. Double-check the spelling.
                  </p>
                </div>
                <div>
                  <label htmlFor="country" className="rule-label">
                    Country
                  </label>
                  <select
                    id="country"
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="mt-2 w-full rounded-md border border-input bg-card px-4 py-3 text-sm outline-none focus:border-primary"
                  >
                    {countries.map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <button
                  type="submit"
                  className="rounded-full bg-primary px-7 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
                >
                  Continue to payment
                </button>
              </form>
            ) : (
              <div>
                <div className="rounded-md border border-border bg-card p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="rule-label">Payment method</p>
                      <p className="mt-2 font-display text-lg font-semibold">Flutterwave</p>
                      <p className="mt-1 text-sm text-muted-foreground">
                        Card, bank transfer, USSD and mobile money — settled in your local
                        currency.
                      </p>
                    </div>
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-accent px-3 py-1 text-xs text-accent-foreground">
                      <ShieldCheck className="h-3.5 w-3.5" /> Secure
                    </span>
                  </div>
                  <div className="mt-6 rounded-md border border-dashed border-border px-4 py-6 text-center text-xs text-muted-foreground">
                    Flutterwave's secure payment window opens here.
                  </div>
                </div>

                <p className="mt-5 text-xs text-muted-foreground">
                  Charged in USD. Your bank may convert at its own rate, so the amount on your
                  statement can differ slightly.
                </p>

                <button
                  type="button"
                  disabled={processing}
                  onClick={pay}
                  className="mt-6 inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-60"
                >
                  <Lock className="h-4 w-4" strokeWidth={1.8} />
                  {processing ? "Confirming payment…" : `Pay ${formatPrice(total)}`}
                </button>
                <p className="mt-3 text-xs text-muted-foreground">
                  Your download link will be available immediately after payment.
                </p>
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="mt-6 block text-xs text-muted-foreground underline underline-offset-4 hover:text-primary"
                >
                  Back to contact info
                </button>
              </div>
            )}
          </div>

          <aside className="h-fit rounded-md border border-border bg-card p-6">
            <h2 className="font-display text-lg font-semibold">Order summary</h2>
            <ul className="mt-5 space-y-3 text-sm">
              {items.map((b) => (
                <li key={b.id} className="flex justify-between gap-4">
                  <span className="text-muted-foreground">
                    {b.title}
                    <span className="block text-[11px] tracking-wide uppercase">
                      {b.formats.join(" · ")}
                    </span>
                  </span>
                  <span>{formatPrice(b.price)}</span>
                </li>
              ))}
            </ul>
            <div className="mt-5 flex justify-between border-t border-border pt-4 text-base font-semibold">
              <span>Total (USD)</span>
              <span>{formatPrice(total)}</span>
            </div>
            <p className="mt-4 text-xs text-muted-foreground">
              No shipping — every title is delivered as a download.
            </p>
          </aside>
        </div>
      </div>
    </SiteLayout>
  );
}
