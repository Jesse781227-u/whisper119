import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { SlidersHorizontal, X } from "lucide-react";
import { useMemo, useState } from "react";
import { BookCard } from "@/components/book-card";
import { SiteLayout } from "@/components/site-layout";
import { categories, formatPrice, publishedBooks, type Format } from "@/data/books";
import { cn } from "@/lib/utils";

type Sort = "newest" | "price-asc" | "price-desc" | "alpha";

type ShopSearch = {
  category?: string | undefined;
  format?: Format | undefined;
  max?: number | undefined;
  sort?: Sort | undefined;
  page?: number | undefined;
};

const PER_PAGE = 6;

export const Route = createFileRoute("/shop")({
  validateSearch: (search: Record<string, unknown>): ShopSearch => ({
    category: typeof search["category"] === "string" ? search["category"] : undefined,
    format:
      search["format"] === "EPUB" || search["format"] === "PDF"
        ? (search["format"] as Format)
        : undefined,
    max: typeof search["max"] === "number" ? search["max"] : undefined,
    sort: ["newest", "price-asc", "price-desc", "alpha"].includes(search["sort"] as string)
      ? (search["sort"] as Sort)
      : undefined,
    page: typeof search["page"] === "number" ? search["page"] : undefined,
  }),

  head: () => ({
    meta: [
      { title: "Shop all ebooks — Whisper 119" },
      {
        name: "description",
        content:
          "Browse every title in the shop by category, price and format. EPUB and PDF ebooks, downloadable the moment you pay.",
      },
      { property: "og:title", content: "Shop all ebooks — Whisper 119" },
      {
        property: "og:description",
        content: "Browse every title by category, price and format. Instant download.",
      },
    ],
  }),
  component: Shop,
});

function Shop() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/shop" });
  const [drawerOpen, setDrawerOpen] = useState(false);

  const sort = search.sort ?? "newest";
  const page = search.page ?? 1;
  const max = search.max ?? 20;

  const setSearch = (next: Partial<ShopSearch>) =>
    navigate({ search: (prev: ShopSearch) => ({ ...prev, page: undefined, ...next }) });


  const filtered = useMemo(() => {
    const list = publishedBooks.filter((b) => {
      if (search.category && b.category !== search.category) return false;
      if (search.format && !b.formats.includes(search.format)) return false;
      if (b.price > max) return false;
      return true;
    });
    const sorted = [...list];
    if (sort === "newest") sorted.sort((a, b) => b.published.localeCompare(a.published));
    if (sort === "price-asc") sorted.sort((a, b) => a.price - b.price);
    if (sort === "price-desc") sorted.sort((a, b) => b.price - a.price);
    if (sort === "alpha") sorted.sort((a, b) => a.title.localeCompare(b.title));
    return sorted;
  }, [search.category, search.format, max, sort]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const current = Math.min(page, pageCount);
  const visible = filtered.slice((current - 1) * PER_PAGE, current * PER_PAGE);
  const hasFilters = Boolean(search.category || search.format || search.max);

  const filters = (
    <div className="space-y-8">
      <div>
        <p className="rule-label">Category</p>
        <ul className="mt-3 space-y-1.5">
          <li>
            <button
              type="button"
              onClick={() => setSearch({ category: undefined })}
              className={cn(
                "text-sm transition-colors hover:text-primary",
                !search.category ? "font-medium text-primary" : "text-muted-foreground",
              )}
            >
              All titles
            </button>
          </li>
          {categories.map((cat) => (
            <li key={cat}>
              <button
                type="button"
                onClick={() => setSearch({ category: cat })}
                className={cn(
                  "text-sm transition-colors hover:text-primary",
                  search.category === cat ? "font-medium text-primary" : "text-muted-foreground",
                )}
              >
                {cat}
              </button>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <p className="rule-label">Price up to</p>
        <input
          type="range"
          min={5}
          max={20}
          step={0.5}
          value={max}
          onChange={(e) => setSearch({ max: Number(e.target.value) })}
          className="mt-4 w-full accent-primary"
        />
        <p className="mt-2 text-sm text-muted-foreground">{formatPrice(max)}</p>
      </div>

      <div>
        <p className="rule-label">Format</p>
        <div className="mt-3 flex gap-2">
          {(["EPUB", "PDF"] as Format[]).map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setSearch({ format: search.format === f ? undefined : f })}
              className={cn(
                "rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
                search.format === f
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border text-muted-foreground hover:border-primary",
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {hasFilters && (
        <button
          type="button"
          onClick={() =>
            navigate({ search: { category: undefined, format: undefined, max: undefined, sort } })
          }
          className="text-xs text-muted-foreground underline underline-offset-4 hover:text-primary"
        >
          Clear all filters
        </button>
      )}
    </div>
  );

  return (
    <SiteLayout>
      <div className="mx-auto max-w-6xl px-5 py-12 sm:px-8">
        <p className="rule-label">The shelf</p>
        <h1 className="mt-3 font-display text-3xl font-semibold sm:text-4xl">
          {search.category ?? "All books"}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {filtered.length} {filtered.length === 1 ? "title" : "titles"} · every purchase is an
          instant download
        </p>

        <div className="mt-10 gap-12 lg:flex">
          <aside className="hidden w-52 shrink-0 lg:block">{filters}</aside>

          <div className="flex-1">
            <div className="flex items-center justify-between gap-3 border-b border-border pb-4">
              <button
                type="button"
                onClick={() => setDrawerOpen(true)}
                className="inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-medium lg:hidden"
              >
                <SlidersHorizontal className="h-3.5 w-3.5" /> Filters
              </button>
              <label className="ml-auto flex items-center gap-2 text-xs text-muted-foreground">
                Sort
                <select
                  value={sort}
                  onChange={(e) => setSearch({ sort: e.target.value as Sort })}
                  className="rounded-md border border-border bg-card px-3 py-2 text-xs text-foreground"
                >
                  <option value="newest">Newest</option>
                  <option value="price-asc">Price: low to high</option>
                  <option value="price-desc">Price: high to low</option>
                  <option value="alpha">A–Z</option>
                </select>
              </label>
            </div>

            {visible.length === 0 ? (
              <div className="mt-16 rounded-md border border-dashed border-border px-8 py-16 text-center">
                <h2 className="font-display text-xl font-semibold">Nothing on this shelf yet</h2>
                <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
                  No titles match those filters. Try widening the price range or clearing the
                  category.
                </p>
                <button
                  type="button"
                  onClick={() => navigate({ search: {} })}
                  className="mt-6 inline-flex rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
                >
                  Show all books
                </button>
              </div>
            ) : (
              <div className="mt-10 grid grid-cols-2 gap-x-6 gap-y-12 md:grid-cols-3">
                {visible.map((book) => (
                  <BookCard key={book.id} book={book} />
                ))}
              </div>
            )}

            {pageCount > 1 && (
              <div className="mt-14 flex items-center justify-center gap-2">
                {Array.from({ length: pageCount }, (_, i) => i + 1).map((p) => (
                  <Link
                    key={p}
                    to="/shop"
                    search={(prev: ShopSearch) => ({ ...prev, page: p })}
                    className={cn(
                      "inline-flex h-9 w-9 items-center justify-center rounded-full border text-sm transition-colors",
                      p === current
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border text-muted-foreground hover:border-primary",
                    )}
                  >
                    {p}
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {drawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            type="button"
            aria-label="Close filters"
            onClick={() => setDrawerOpen(false)}
            className="absolute inset-0 bg-foreground/40"
          />
          <div className="absolute inset-x-0 bottom-0 max-h-[80vh] overflow-y-auto rounded-t-xl bg-card px-6 pt-6 pb-10">
            <div className="mb-6 flex items-center justify-between">
              <p className="font-display text-lg font-semibold">Filters</p>
              <button type="button" onClick={() => setDrawerOpen(false)} aria-label="Close">
                <X className="h-5 w-5" />
              </button>
            </div>
            {filters}
          </div>
        </div>
      )}
    </SiteLayout>
  );
}
