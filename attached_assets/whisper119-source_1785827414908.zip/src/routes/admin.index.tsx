import { createFileRoute, Link } from "@tanstack/react-router";
import { AdminShell, StatusPill } from "@/components/admin-shell";
import { books, formatPrice, orders, orderTotal } from "@/data/books";

export const Route = createFileRoute("/admin/")({
  head: () => ({
    meta: [
      { title: "Dashboard — Whisper 119 admin" },
      { name: "description", content: "Orders, revenue and catalogue overview for the shop." },
      { property: "og:title", content: "Dashboard — Whisper 119 admin" },
      { property: "og:description", content: "Orders, revenue and catalogue overview." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminDashboard,
});


function AdminDashboard() {
  const pending = orders.filter((o) => o.status === "pending").length;
  const revenue = orders
    .filter((o) => o.status === "paid")
    .reduce((s, o) => s + orderTotal(o), 0);

  const stats = [
    { label: "Total orders", value: orders.length },
    { label: "Pending orders", value: pending },
    { label: "Books listed", value: books.length },
    { label: "Revenue (paid)", value: formatPrice(revenue) },
  ];

  return (
    <AdminShell title="Dashboard" description="A quick look at the shop today.">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-md border border-border bg-card p-5">
            <p className="rule-label">{s.label}</p>
            <p className="mt-3 font-display text-2xl font-semibold">{s.value}</p>
          </div>
        ))}
      </div>

      <section className="mt-10">
        <div className="flex items-end justify-between">
          <h2 className="font-display text-lg font-semibold">Recent orders</h2>
          <Link to="/admin/orders" className="text-xs text-muted-foreground hover:text-primary">
            View all →
          </Link>
        </div>
        <div className="mt-4 overflow-x-auto rounded-md border border-border bg-card">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                <th className="rule-label px-4 py-3">Order</th>
                <th className="rule-label px-4 py-3">Buyer</th>
                <th className="rule-label px-4 py-3">Amount</th>
                <th className="rule-label px-4 py-3">Status</th>
                <th className="rule-label px-4 py-3">Date</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id} className="border-b border-border last:border-0">
                  <td className="px-4 py-3">
                    <Link
                      to="/admin/orders/$orderId"
                      params={{ orderId: o.id }}
                      className="font-medium hover:text-primary"
                    >
                      {o.id}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{o.buyer}</td>
                  <td className="px-4 py-3">{formatPrice(orderTotal(o))}</td>
                  <td className="px-4 py-3">
                    <StatusPill status={o.status} />
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{o.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </AdminShell>
  );
}
