import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { Check, Download, FileText, Globe2 } from "lucide-react";
import { toast } from "sonner";
import { BookCard, BookCover } from "@/components/book-card";
import { SiteLayout } from "@/components/site-layout";
import { formatPrice, getBook, publishedBooks } from "@/data/books";
import { useCart } from "@/lib/cart";

export const Route = createFileRoute("/book/$bookId")({
  loader: ({ params }) => {
    const book = getBook(params.bookId);
    if (!book) throw notFound();
    return { book };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Title unavailable — Whisper 119" }, { name: "robots", content: "noindex" }],
      };
    }
    const { book } = loaderData;
    const title = `${book.title} by ${book.author} — Whisper 119`;
    return {
      meta: [
        { title },
        { name: "description", content: book.blurb },
        { property: "og:title", content: title },
        { property: "og:description", content: book.blurb },
      ],
    };
  },
  component: BookDetail,
});

function BookDetail() {
  const { book } = Route.useLoaderData();
  const { add, has } = useCart();
  const navigate = useNavigate();
  const inCart = has(book.id);

  const related = publishedBooks
    .filter((b) => b.id !== book.id && (b.category === book.category || b.author === book.author))
    .slice(0, 4);

  return (
    <SiteLayout>
      <div className="mx-auto max-w-6xl px-5 py-12 sm:px-8">
        <nav className="text-xs text-muted-foreground">
          <Link to="/shop" className="hover:text-primary">
            Shop
          </Link>
          <span className="mx-2">/</span>
          <Link to="/shop" search={{ category: book.category }} className="hover:text-primary">
            {book.category}
          </Link>
        </nav>

        <div className="mt-8 grid gap-12 md:grid-cols-[0.85fr_1fr]">
          <div className="mx-auto w-full max-w-xs md:max-w-none">
            <BookCover book={book} className="aspect-[2/3]" priority />
          </div>

          <div>
            <p className="rule-label">{book.category}</p>
            <h1 className="mt-3 font-display text-3xl leading-tight font-semibold text-balance sm:text-4xl">
              {book.title}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">by {book.author}</p>

            <div className="mt-7 flex flex-wrap items-center gap-3">
              <span className="font-display text-2xl font-semibold">
                {formatPrice(book.price)}
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-foreground">
                <Download className="h-3.5 w-3.5" /> Instant download after purchase
              </span>
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => {
                  if (!inCart) add(book.id);
                  toast.success(`${book.title} is in your cart`);
                }}
                className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-medium transition-colors hover:border-primary hover:text-primary"
              >
                {inCart && <Check className="h-4 w-4" />}
                {inCart ? "In cart" : "Add to cart"}
              </button>
              <button
                type="button"
                onClick={() => {
                  add(book.id);
                  navigate({ to: "/checkout" });
                }}
                className="rounded-full bg-primary px-7 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Buy now
              </button>
            </div>

            <dl className="mt-10 grid grid-cols-2 gap-6 border-t border-border pt-8 sm:grid-cols-3">
              <div>
                <dt className="rule-label">Format</dt>
                <dd className="mt-1.5 inline-flex items-center gap-1.5 text-sm">
                  <FileText className="h-4 w-4 text-muted-foreground" strokeWidth={1.6} />
                  {book.formats.join(" & ")}
                </dd>
              </div>
              <div>
                <dt className="rule-label">Length</dt>
                <dd className="mt-1.5 text-sm">{book.pages} pages</dd>
              </div>
              <div>
                <dt className="rule-label">Published</dt>
                <dd className="mt-1.5 text-sm">
                  {new Date(book.published).toLocaleDateString("en-GB", {
                    month: "long",
                    year: "numeric",
                  })}
                </dd>
              </div>
            </dl>

            <div className="mt-10">
              <h2 className="font-display text-lg font-semibold">About this book</h2>
              <p className="mt-3 leading-relaxed text-muted-foreground">{book.description}</p>
            </div>

            <p className="mt-8 inline-flex items-center gap-2 text-xs text-muted-foreground">
              <Globe2 className="h-4 w-4" strokeWidth={1.6} /> Priced in USD · pay in your local
              currency at checkout
            </p>
          </div>
        </div>

        {related.length > 0 && (
          <section className="mt-24">
            <h2 className="font-display text-2xl font-semibold">You might also like</h2>
            <div className="mt-8 grid grid-cols-2 gap-x-6 gap-y-10 md:grid-cols-4">
              {related.map((b) => (
                <BookCard key={b.id} book={b} />
              ))}
            </div>
          </section>
        )}
      </div>
    </SiteLayout>
  );
}
