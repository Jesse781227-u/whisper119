import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { AdminShell, StatusPill } from "@/components/admin-shell";
import { books, formatPrice, orders, orderTotal, type Order } from "@/data/books";


export const Route = createFileRoute("/admin/orders/$orderId")({
  loader: ({ params }) => {
    const order = orders.find((o) => o.id === params.orderId);
    if (!order) throw notFound();
    return { order };
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `Order ${loaderData.order.id} — Whisper 119 admin` : "Order — Whisper 119 admin" },
      { name: "description", content: "Buyer details, items, payment status and download activity." },
      { property: "og:title", content: "Order detail — Whisper 119 admin" },
      { property: "og:description", content: "Buyer details, items and download activity." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminOrderDetail,
});

function AdminOrderDetail() {
  const { order } = Route.useLoaderData();

  return (
    <AdminShell title={`Order ${order.id}`} description={`Placed ${order.date}`}>
      <Link
        to="/admin/orders"
        className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> All orders
      </Link>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_18rem]">
        <div className="rounded-md border border-border bg-card">
          <div className="border-b border-border px-5 py-3">
            <p className="rule-label">Items</p>
          </div>
          <ul className="divide-y divide-border">
            {order.items.map((item: Order["items"][number]) => {
              const book = books.find((b) => b.id === item.bookId);
              return (
                <li key={item.bookId} className="flex items-center gap-4 px-5 py-4">
                  {book && (
                    <img
                      src={book.cover}
                      alt=""
                      width={672}
                      height={992}
                      loading="lazy"
                      className="h-14 w-10 rounded-xs object-cover"
                    />
                  )}
                  <div className="flex-1">
                    <p className="font-medium">{book?.title ?? item.bookId}</p>
                    <p className="text-xs text-muted-foreground">
                      {book?.author} · {book?.formats.join(", ")}
                    </p>
                  </div>
                  <span className="text-sm">{formatPrice(item.price)}</span>
                </li>
              );
            })}
          </ul>
          <div className="flex justify-between border-t border-border px-5 py-4 text-sm font-semibold">
            <span>Total</span>
            <span>{formatPrice(orderTotal(order))}</span>
          </div>
        </div>

        <aside className="space-y-6">
          <div className="rounded-md border border-border bg-card p-5">
            <p className="rule-label">Buyer</p>
            <p className="mt-3 text-sm font-medium">{order.buyer}</p>
            <p className="text-sm text-muted-foreground">{order.email}</p>
            <p className="text-sm text-muted-foreground">{order.country}</p>
          </div>
          <div className="rounded-md border border-border bg-card p-5">
            <p className="rule-label">Payment</p>
            <div className="mt-3">
              <StatusPill status={order.status} />
            </div>
            <p className="mt-3 text-xs text-muted-foreground">Flutterwave · charged in USD</p>
          </div>
          <div className="rounded-md border border-border bg-card p-5">
            <p className="rule-label">Download activity</p>
            <p className="mt-3 text-sm">
              {order.downloaded
                ? "Buyer has downloaded their files."
                : "No downloads yet — links are still live."}
            </p>
          </div>
        </aside>
      </div>
    </AdminShell>
  );
}
