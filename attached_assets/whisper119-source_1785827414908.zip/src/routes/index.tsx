import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Download, Globe2 } from "lucide-react";
import { BookCard, BookCover } from "@/components/book-card";
import { SiteLayout } from "@/components/site-layout";
import { categories, formatPrice, publishedBooks } from "@/data/books";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Whisper 119 — A Boutique Digital Bookshop" },
      {
        name: "description",
        content:
          "Handpicked ebooks in EPUB and PDF, delivered the moment you pay. A small independent bookshop that ships to every inbox in the world.",
      },
      { property: "og:title", content: "Whisper 119 — A Boutique Digital Bookshop" },
      {
        property: "og:description",
        content: "Handpicked ebooks in EPUB and PDF, delivered the moment you pay.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  const hero = publishedBooks.find((b) => b.featured)!;
  const arrivals = [...publishedBooks]
    .sort((a, b) => b.published.localeCompare(a.published))
    .slice(0, 6);

  return (
    <SiteLayout>
      {/* Hero */}
      <section className="border-b border-border/70 bg-parchment/50">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-16 sm:px-8 md:grid-cols-[1fr_0.8fr] md:py-24">
          <div className="animate-fade-rise">
            <p className="rule-label">This month's shelf</p>
            <h1 className="mt-4 font-display text-4xl leading-[1.05] font-semibold text-balance sm:text-5xl md:text-6xl">
              {hero.title}
            </h1>
            <p className="mt-3 text-sm tracking-wide text-muted-foreground uppercase">
              by {hero.author}
            </p>
            <p className="mt-6 max-w-md text-base leading-relaxed text-muted-foreground">
              {hero.blurb}
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-4">
              <Link
                to="/shop"
                className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Browse the shop <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/book/$bookId"
                params={{ bookId: hero.id }}
                className="text-sm font-medium underline underline-offset-4 hover:text-primary"
              >
                Read about this title
              </Link>
            </div>
            <div className="mt-10 flex flex-wrap gap-x-8 gap-y-3 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-2">
                <Download className="h-4 w-4" strokeWidth={1.6} /> Instant download
              </span>
              <span className="inline-flex items-center gap-2">
                <Globe2 className="h-4 w-4" strokeWidth={1.6} /> Ships to every country
              </span>
            </div>
          </div>

          <div className="mx-auto w-full max-w-xs md:max-w-sm">
            <Link to="/book/$bookId" params={{ bookId: hero.id }} className="block hover-lift">
              <BookCover book={hero} className="aspect-[2/3]" priority />
            </Link>
          </div>
        </div>
      </section>

      {/* New arrivals */}
      <section className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="rule-label">Fresh off the press</p>
            <h2 className="mt-2 font-display text-2xl font-semibold sm:text-3xl">New arrivals</h2>
          </div>
          <Link
            to="/shop"
            className="hidden text-sm text-muted-foreground hover:text-primary sm:inline"
          >
            See all →
          </Link>
        </div>

        <div className="no-scrollbar -mx-5 mt-8 flex snap-x gap-6 overflow-x-auto px-5 pb-4 sm:-mx-8 sm:px-8">
          {arrivals.map((book) => (
            <Link
              key={book.id}
              to="/book/$bookId"
              params={{ bookId: book.id }}
              className="w-40 shrink-0 snap-start sm:w-48"
            >
              <div className="hover-lift">
                <BookCover book={book} className="aspect-[2/3]" />
              </div>
              <h3 className="mt-3 font-display text-sm leading-snug font-semibold">
                {book.title}
              </h3>
              <p className="text-xs text-muted-foreground">{book.author}</p>
              <p className="mt-1 text-xs font-medium">{formatPrice(book.price)}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-6xl px-5 pb-8 sm:px-8">
        <p className="rule-label">Wander by mood</p>
        <h2 className="mt-2 font-display text-2xl font-semibold sm:text-3xl">Categories</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((cat) => {
            const count = publishedBooks.filter((b) => b.category === cat).length;
            return (
              <Link
                key={cat}
                to="/shop"
                search={{ category: cat }}
                className="group flex items-center justify-between rounded-md border border-border bg-card px-6 py-7 transition-colors hover:border-primary hover:bg-accent/50"
              >
                <div>
                  <span className="font-display text-lg font-semibold">{cat}</span>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {count} {count === 1 ? "title" : "titles"}
                  </p>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-primary" />
              </Link>
            );
          })}
        </div>
      </section>

      {/* Editorial strip */}
      <section className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
        <div className="rounded-md border border-border bg-parchment/60 px-8 py-12 text-center">
          <p className="rule-label">A note from the shop</p>
          <p className="mx-auto mt-5 max-w-2xl font-display text-xl leading-relaxed text-balance sm:text-2xl">
            "I read every title before it goes on the shelf. If it's here, it's because I'd press
            it into a friend's hands."
          </p>
          <p className="mt-5 text-xs tracking-widest text-muted-foreground uppercase">
            — The bookseller
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-4 sm:px-8">
        <h2 className="font-display text-2xl font-semibold sm:text-3xl">On the shelf now</h2>
        <div className="mt-8 grid grid-cols-2 gap-x-6 gap-y-10 md:grid-cols-4">
          {publishedBooks.slice(0, 4).map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
