import cover1 from "@/assets/cover-1.jpg";
import cover2 from "@/assets/cover-2.jpg";
import cover3 from "@/assets/cover-3.jpg";
import cover4 from "@/assets/cover-4.jpg";

export type Format = "EPUB" | "PDF";

export type Book = {
  id: string;
  title: string;
  author: string;
  price: number;
  category: string;
  formats: Format[];
  cover: string;
  blurb: string;
  description: string;
  pages: number;
  published: string;
  featured?: boolean;
  status: "Published" | "Draft";
};

export const categories = [
  "Fiction",
  "Non-Fiction",
  "Self-Help",
  "Poetry",
  "Essays",
] as const;

export const books: Book[] = [
  {
    id: "where-the-river-remembers",
    title: "Where the River Remembers",
    author: "Arundhati Sen",
    price: 12.0,
    category: "Fiction",
    formats: ["EPUB", "PDF"],
    cover: cover1,
    blurb:
      "A luminous novel about memory, migration, and the small rituals that keep a family whole.",
    description:
      "Three generations of the Nayar family return to a house by a river that is slowly disappearing. Told across four decades and two continents, Where the River Remembers is a patient, tender study of what we carry and what we let the current take. Arundhati Sen writes with the quiet authority of someone who has been listening for a very long time.",
    pages: 328,
    published: "2026-05-14",
    featured: true,
    status: "Published",
  },
  {
    id: "the-silence-between-stars",
    title: "The Silence Between Stars",
    author: "Juliet Morgan",
    price: 10.5,
    category: "Fiction",
    formats: ["EPUB"],
    cover: cover2,
    blurb: "A hushed debut about two astronomers and the year they stopped speaking.",
    description:
      "In a remote observatory on the edge of the Atacama, two researchers map a sky they can no longer describe to each other. Juliet Morgan's debut is spare, precise, and devastating — a book about distance measured in both light years and dinner tables.",
    pages: 244,
    published: "2026-03-02",
    status: "Published",
  },
  {
    id: "beyond-the-horizon",
    title: "Beyond the Horizon",
    author: "Reid Wilson",
    price: 14.0,
    category: "Non-Fiction",
    formats: ["PDF", "EPUB"],
    cover: cover3,
    blurb: "A field guide to building a life with purpose, clarity, and less noise.",
    description:
      "Drawing on a decade of work with founders, teachers and clinicians, Reid Wilson lays out a practical framework for deciding what deserves your attention. Not a productivity book — a direction book.",
    pages: 290,
    published: "2026-01-20",
    status: "Published",
  },
  {
    id: "the-art-of-choosing-you",
    title: "The Art of Choosing You",
    author: "Rowan Hayes",
    price: 9.0,
    category: "Self-Help",
    formats: ["EPUB", "PDF"],
    cover: cover4,
    blurb: "A gentle guide to coming home to yourself, one honest choice at a time.",
    description:
      "Rowan Hayes writes for anyone who has spent years being agreeable. Part memoir, part workbook, The Art of Choosing You is warm, unsentimental, and full of prompts you'll actually finish.",
    pages: 208,
    published: "2026-06-08",
    featured: true,
    status: "Published",
  },
  {
    id: "salt-and-small-hours",
    title: "Salt & Small Hours",
    author: "Nia Adeyemi",
    price: 8.5,
    category: "Poetry",
    formats: ["PDF"],
    cover: cover1,
    blurb: "Forty poems written between midnight and the first ferry.",
    description:
      "Nia Adeyemi's second collection moves between Lagos, Lisbon and a rented room above a laundrette. Salt & Small Hours is about insomnia, inheritance, and the particular loneliness of loving a city that doesn't know your name.",
    pages: 96,
    published: "2025-11-11",
    status: "Published",
  },
  {
    id: "notes-on-leaving",
    title: "Notes on Leaving",
    author: "Theo Marchetti",
    price: 11.0,
    category: "Essays",
    formats: ["EPUB", "PDF"],
    cover: cover2,
    blurb: "Twelve essays on departure — from countries, jobs, faiths and people.",
    description:
      "Theo Marchetti has left more places than most people have visited. These essays examine the moment before the door closes: the calculation, the guilt, the strange lightness that follows.",
    pages: 176,
    published: "2026-02-26",
    status: "Published",
  },
  {
    id: "the-long-quiet-work",
    title: "The Long, Quiet Work",
    author: "Imogen Blake",
    price: 13.5,
    category: "Non-Fiction",
    formats: ["EPUB"],
    cover: cover3,
    blurb: "What craftspeople know about mastery that the internet keeps forgetting.",
    description:
      "A bookbinder, a violin maker, a typesetter and a beekeeper. Imogen Blake spends a year in four workshops and returns with an argument for slowness that never once scolds you.",
    pages: 262,
    published: "2025-09-30",
    status: "Published",
  },
  {
    id: "small-brave-mornings",
    title: "Small Brave Mornings",
    author: "Rowan Hayes",
    price: 7.5,
    category: "Self-Help",
    formats: ["PDF"],
    cover: cover4,
    blurb: "Sixty short readings for the first ten minutes of the day.",
    description:
      "A companion volume to The Art of Choosing You. One page a day, no streaks to keep, nothing to log. Just a steady voice for the part of the morning that decides the rest of it.",
    pages: 132,
    published: "2026-06-30",
    status: "Draft",
  },
];

export const publishedBooks = books.filter((b) => b.status === "Published");

export const getBook = (id: string) => books.find((b) => b.id === id);

export const formatPrice = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n);

export type OrderStatus = "paid" | "pending";

export type Order = {
  id: string;
  buyer: string;
  email: string;
  country: string;
  date: string;
  status: OrderStatus;
  downloaded: boolean;
  items: { bookId: string; price: number }[];
};

export const orders: Order[] = [
  {
    id: "MRG-10428",
    buyer: "Amara Okoye",
    email: "amara.okoye@example.com",
    country: "Nigeria",
    date: "2026-07-31",
    status: "paid",
    downloaded: true,
    items: [
      { bookId: "where-the-river-remembers", price: 12 },
      { bookId: "salt-and-small-hours", price: 8.5 },
    ],
  },
  {
    id: "MRG-10427",
    buyer: "Lucas Meyer",
    email: "l.meyer@example.de",
    country: "Germany",
    date: "2026-07-30",
    status: "paid",
    downloaded: false,
    items: [{ bookId: "beyond-the-horizon", price: 14 }],
  },
  {
    id: "MRG-10426",
    buyer: "Priya Raman",
    email: "priya.r@example.in",
    country: "India",
    date: "2026-07-29",
    status: "pending",
    downloaded: false,
    items: [{ bookId: "the-art-of-choosing-you", price: 9 }],
  },
  {
    id: "MRG-10425",
    buyer: "Sofia Alvarez",
    email: "sofia@example.mx",
    country: "Mexico",
    date: "2026-07-28",
    status: "paid",
    downloaded: true,
    items: [
      { bookId: "notes-on-leaving", price: 11 },
      { bookId: "the-long-quiet-work", price: 13.5 },
    ],
  },
  {
    id: "MRG-10424",
    buyer: "James Whitfield",
    email: "jw@example.co.uk",
    country: "United Kingdom",
    date: "2026-07-27",
    status: "pending",
    downloaded: false,
    items: [{ bookId: "the-silence-between-stars", price: 10.5 }],
  },
];

export const orderTotal = (o: Order) => o.items.reduce((s, i) => s + i.price, 0);

export const countries = [
  "Nigeria",
  "Ghana",
  "Kenya",
  "South Africa",
  "United States",
  "United Kingdom",
  "Germany",
  "France",
  "India",
  "Canada",
  "Australia",
  "Brazil",
];
