import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { books, type Book } from "@/data/books";

type CartContextValue = {
  ids: string[];
  items: Book[];
  total: number;
  count: number;
  has: (id: string) => boolean;
  add: (id: string) => void;
  remove: (id: string) => void;
  clear: () => void;
};

const CartContext = createContext<CartContextValue | null>(null);

const STORAGE_KEY = "whisper119.cart";

export function CartProvider({ children }: { children: ReactNode }) {
  const [ids, setIds] = useState<string[]>([]);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setIds(JSON.parse(raw) as string[]);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
    } catch {
      /* ignore */
    }
  }, [ids]);

  const value = useMemo<CartContextValue>(() => {
    const items = ids
      .map((id) => books.find((b) => b.id === id))
      .filter((b): b is Book => Boolean(b));
    return {
      ids,
      items,
      count: items.length,
      total: items.reduce((s, b) => s + b.price, 0),
      has: (id) => ids.includes(id),
      add: (id) => setIds((prev) => (prev.includes(id) ? prev : [...prev, id])),
      remove: (id) => setIds((prev) => prev.filter((x) => x !== id)),
      clear: () => setIds([]),
    };
  }, [ids]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
